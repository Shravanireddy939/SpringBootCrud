package com.anurag.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anurag.demo.entity.Employee;
import com.anurag.demo.service.EmployeeService;

@RestController
@RequestMapping("/Employee")
@CrossOrigin("http://localhost:4000")
public class EmpRestController {

	@Autowired
	EmployeeService empService;
	@PostMapping("/CreateAccount")
	public String CreateAccount(@RequestBody Employee emp) {
		return empService.createEmployee(emp);
	}
}
