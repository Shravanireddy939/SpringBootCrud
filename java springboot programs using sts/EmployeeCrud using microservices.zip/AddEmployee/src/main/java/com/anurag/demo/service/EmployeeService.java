package com.anurag.demo.service;

import com.anurag.demo.entity.Employee;

public interface EmployeeService {

	String createEmployee(Employee emp);

}
