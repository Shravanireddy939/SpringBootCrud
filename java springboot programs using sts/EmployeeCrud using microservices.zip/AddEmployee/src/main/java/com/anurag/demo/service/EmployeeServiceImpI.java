package com.anurag.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anurag.demo.dao.EmployeeDao;
import com.anurag.demo.entity.Employee;

@Service
public class EmployeeServiceImpI implements EmployeeService{
	
	@Autowired
	EmployeeDao empDao;

	@Override
	public String createEmployee(Employee emp) {
		// TODO Auto-generated method stub
		 empDao.save(emp);
		 return "Employee has been Created";
	}

}
