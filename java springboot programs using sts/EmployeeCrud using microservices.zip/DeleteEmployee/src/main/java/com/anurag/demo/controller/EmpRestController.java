package com.anurag.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.anurag.demo.entity.Employee;
import com.anurag.demo.service.EmployeeService;


@RestController
@RequestMapping("/Employee")
@CrossOrigin("http://localhost:4001")
public class EmpRestController {
	RestTemplate rest;
	@Autowired
	EmployeeService empService;

	@DeleteMapping("/deleteEmp/{empId}")
	public String deleteEmp(@PathVariable Integer empId) {
		
		Employee employee=rest.getForObject("http://localhost:4000/Employee/CreateAccount",Employee.class);
		if(employee!=null)
			return empService.deleteEmpById(empId);
		else
			return "Employee not Found";
		

}
}
