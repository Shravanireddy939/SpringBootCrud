package com.anurag.demo.service;


public interface EmployeeService {
	
	String deleteEmpById(Integer empId);

}
