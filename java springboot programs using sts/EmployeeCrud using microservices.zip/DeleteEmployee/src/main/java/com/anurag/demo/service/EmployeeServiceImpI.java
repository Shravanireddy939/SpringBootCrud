package com.anurag.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anurag.demo.dao.EmployeeDao;

@Service
public class EmployeeServiceImpI implements EmployeeService{
	
	@Autowired
	EmployeeDao empDao;

	@Override
	public String deleteEmpById(Integer empId) {
		// TODO Auto-generated method stub
		empDao.exists(empId);
			empDao.delete(empId);
			return "Deleted Successfully";
		
		}
	}
