package com.anurag.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anurag.demo.entity.Employee;
import com.anurag.demo.service.EmployeeService;

@RestController
@RequestMapping("/Employee")
@CrossOrigin("http://localhost:4002")
public class EmpRestController {

	@Autowired
	EmployeeService empService;
	@GetMapping("/findAll")
	public List<Employee> findAllEmployee(){
		return empService.findAllEmployee();
	}
}

