package com.anurag.demo.service;

import java.util.List;

import com.anurag.demo.entity.Employee;

public interface EmployeeService {



	List<Employee> findAllEmployee();

}
