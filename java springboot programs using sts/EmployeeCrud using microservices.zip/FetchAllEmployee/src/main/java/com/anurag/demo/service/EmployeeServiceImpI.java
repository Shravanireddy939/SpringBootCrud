package com.anurag.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anurag.demo.dao.EmployeeDao;
import com.anurag.demo.entity.Employee;

@Service
public class EmployeeServiceImpI implements EmployeeService{
	
	@Autowired
	EmployeeDao empDao;

	@Override
	public List<Employee> findAllEmployee() {
		// TODO Auto-generated method stub
		List<Employee> employees=empDao.findAll();
		return employees;
	}


}
