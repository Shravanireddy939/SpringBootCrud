package com.anurag.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anurag.demo.entity.Employee;
import com.anurag.demo.service.EmployeeService;

@RestController
@RequestMapping("/Employee")
@CrossOrigin("http://localhost:4003")
public class EmpRestController {

	@Autowired
	EmployeeService empService;
	@GetMapping("/findById/{empId}")
	public Employee findEmployeeById(@PathVariable Integer empId){
		return empService.findEmpById(empId);
}
}
