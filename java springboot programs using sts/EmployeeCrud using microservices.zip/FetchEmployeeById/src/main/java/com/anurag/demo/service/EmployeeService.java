package com.anurag.demo.service;

import com.anurag.demo.entity.Employee;

public interface EmployeeService {

	Employee findEmpById(Integer empId);

}
