package com.anurag.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anurag.demo.dao.EmployeeDao;
import com.anurag.demo.entity.Employee;

@Service
public class EmployeeServiceImpI implements EmployeeService{
	
	@Autowired
	EmployeeDao empDao;

	@Override
	public Employee findEmpById(Integer empId) {
		// TODO Auto-generated method stub
		return empDao.findOne(empId);
	}



}
