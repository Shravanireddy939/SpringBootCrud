package com.anurag.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.anurag.demo.entity.Employee;
import com.anurag.demo.service.EmployeeService;

@RestController
@RequestMapping("/Employee")
@CrossOrigin("http://localhost:4004")
public class EmpRestController {


	RestTemplate rest;
	@Autowired
	EmployeeService empService;
	@PutMapping("/updateEmp")
	public String updateEmp(@RequestBody Employee emp) {
		Employee employee=rest.getForObject("http://localhost:4000/Employee/CreateAccount",Employee.class);
		if(employee!=null)
			return empService.updateEmployee(emp);
		else
			return "New Employee is Inserted";
	}
}

