package Exceptions;

public class BasicIdException extends Exception {

	public BasicIdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BasicIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
