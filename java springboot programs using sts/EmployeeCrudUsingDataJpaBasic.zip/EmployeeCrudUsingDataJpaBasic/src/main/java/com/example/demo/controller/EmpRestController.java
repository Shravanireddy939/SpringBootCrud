package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

import Exceptions.BasicIdException;


@RestController
@RequestMapping("/Bank")
@CrossOrigin("http://localhost:4200")
public class EmpRestController {

@Autowired
EmployeeService empService;
@PostMapping(value="/CreateAccount",consumes={"application/xml"},produces="application/xml")
public String CreateAccount(@RequestBody Employee emp) {
	return empService.createEmployee(emp);
}
@GetMapping("/findById/{empId},method = RequestMethod.GET,headers=\"Accept=application/json")
public Employee findEmployeeById(@PathVariable Integer empId) throws BasicIdException{
	Employee c =null;
	try {
	c= empService.findEmpById(empId);	
		System.out.println("employee "+c);
		}catch(Exception e) {
			throw new BasicIdException("No employee with this ID");
		}
		return c;
	}

@GetMapping("/findAll")
public List<Employee> findAllEmployee(){
	return empService.findAllEmployee();
}

@PutMapping("/updateEmp")
public String updateEmp(@RequestBody Employee emp) {
	return empService.updateEmployee(emp);
}
@DeleteMapping("/deleteEmp/{empId}")
	public String deleteEmp(@PathVariable Integer empId) {
	 empService.deleteEmpById(empId);
	 return "Deleted Successfully";
  }

// Exception Handling in controller level
@ResponseStatus(value=HttpStatus.NOT_FOUND,
		   reason="employee id not found")
@ExceptionHandler({Exception.class})
public void handleException(){
	   
}
}
