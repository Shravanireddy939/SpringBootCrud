package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Employee;

public interface EmployeeService {

	String createEmployee(Employee emp);

	Employee findEmpById(Integer empId);

	List<Employee> findAllEmployee();

	String updateEmployee(Employee emp);

	String deleteEmpById(Integer empId);
	
}
