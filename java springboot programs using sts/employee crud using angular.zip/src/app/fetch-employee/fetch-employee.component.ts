import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fetch-employee',
  templateUrl: './fetch-employee.component.html',
  styleUrls: ['./fetch-employee.component.css']
})
export class FetchEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}